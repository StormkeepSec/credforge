credforge brand assets

The primary icon derives from the supplied credforge.svg.
The reverse icon changes slate to canvas for dark surfaces.
Horizontal wordmarks use live Segoe UI/Arial text in SVG; convert text to outlines for print production.
The campaign PNGs are concept examples with editable copy and no product UI claims.
